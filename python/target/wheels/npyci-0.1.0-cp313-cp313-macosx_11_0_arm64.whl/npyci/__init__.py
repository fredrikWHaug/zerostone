from .npyci import *

__doc__ = npyci.__doc__
if hasattr(npyci, "__all__"):
    __all__ = npyci.__all__